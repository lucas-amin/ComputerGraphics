import os


class Map()
	def __init__ ():




application_directory = "../../2019cglib/applications/appImage"
sample_image = "../../2019cglib/applications/imagens/maxmin2.pgm"


if __name__ == "__main__":
	result = (exec(application_directory + " " + sample_image).read())
	print(result)
	map = Map()